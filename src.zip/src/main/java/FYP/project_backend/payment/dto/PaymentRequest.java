package FYP.project_backend.payment.dto;

import FYP.project_backend.enums.PaymentMethod;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class PaymentRequest {

    @NotBlank
    private String controlNumber;

    @NotNull
    private PaymentMethod paymentMethod;

    @NotNull
    @DecimalMin("0.01")
    private BigDecimal amount;
}